package com.cheeze.pizza.pizzacheeze.types

data class Pic(val uri: String, val id: String)